import { createBrowserRouter } from "react-router";
import { LoginPage } from "./pages/login-page";
import { SignupPage } from "./pages/signup-page";
import { DashboardPage } from "./pages/dashboard-page";
import { UploadMaterialPage } from "./pages/upload-material-page";
import { CreateQuestionPage } from "./pages/create-question-page";
import { TestPage } from "./pages/test-page";
import { LibraryPage } from "./pages/library-page";
import { SettingsPage } from "./pages/settings-page";
import { ProfilePage } from "./pages/profile-page";
import { PackageManagePage } from "./pages/package-manage-page";
import { PackageViewPage } from "./pages/package-view-page";
import { MaterialModifyPage } from "./pages/material-modify-page";
import { EditProfilePage } from "./pages/edit-profile-page";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LoginPage,
  },
  {
    path: "/signup",
    Component: SignupPage,
  },
  {
    path: "/dashboard",
    Component: DashboardPage,
  },
  {
    path: "/upload",
    Component: UploadMaterialPage,
  },
  {
    path: "/create",
    Component: CreateQuestionPage,
  },
  {
    path: "/test/:id",
    Component: TestPage,
  },
  {
    path: "/library",
    Component: LibraryPage,
  },
  {
    path: "/settings",
    Component: SettingsPage,
  },
  {
    path: "/profile",
    Component: ProfilePage,
  },
  {
    path: "/profile/:id",
    Component: ProfilePage,
  },
  {
    path: "/package/:id/manage",
    Component: PackageManagePage,
  },
  {
    path: "/package/:id",
    Component: PackageViewPage,
  },
  {
    path: "/material/:id/modify",
    Component: MaterialModifyPage,
  },
  {
    path: "/profile/edit",
    Component: EditProfilePage,
  },
]);
