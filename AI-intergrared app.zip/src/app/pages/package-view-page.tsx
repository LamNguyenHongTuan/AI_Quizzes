import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Brain, ArrowLeft, BookOpen, Edit, Package, Heart, Download } from 'lucide-react';
import { Badge } from '../components/ui/badge';
import { toast } from 'sonner';

// Mock package with materials
const mockPackage = {
  id: 'pkg1',
  name: 'Web Development Basics',
  description: 'A comprehensive collection of web development fundamentals',
  tags: ['Web', 'Programming', 'Frontend'],
  materials: [
    {
      id: '1',
      title: 'Introduction to React Hooks',
      type: 'AI Generated',
      questionsCount: 15,
      flashcardsCount: 20,
      tags: ['React', 'JavaScript'],
      likes: 42,
    },
    {
      id: '2',
      title: 'JavaScript Fundamentals',
      type: 'Custom',
      questionsCount: 10,
      flashcardsCount: 15,
      tags: ['JavaScript'],
      likes: 28,
    },
    {
      id: '3',
      title: 'CSS Grid and Flexbox',
      type: 'AI Generated',
      questionsCount: 12,
      flashcardsCount: 18,
      tags: ['CSS', 'Layout'],
      likes: 35,
    },
  ],
  totalQuestions: 37,
  totalFlashcards: 53,
  totalLikes: 105,
  downloads: 234,
};

export function PackageViewPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [liked, setLiked] = useState(false);

  const handleLike = () => {
    setLiked(!liked);
    toast.success(liked ? 'Removed from favorites' : 'Added to favorites');
  };

  const handleDownload = () => {
    toast.success('Package added to your materials!');
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-2 rounded-lg">
              <Package className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-semibold">Package Details</span>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Package Header */}
        <Card className="mb-6 border-purple-200 dark:border-purple-800">
          <CardContent className="pt-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <Package className="w-8 h-8 text-purple-600 dark:text-purple-400" />
                  <h1 className="text-3xl font-bold">{mockPackage.name}</h1>
                  <Badge className="bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300">
                    Package
                  </Badge>
                </div>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  {mockPackage.description}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {mockPackage.tags.map(tag => (
                    <Badge key={tag} variant="outline" className="bg-purple-50 dark:bg-purple-950">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleLike}
                  className={liked ? 'text-red-500' : ''}
                >
                  <Heart className={`w-4 h-4 ${liked ? 'fill-current' : ''}`} />
                </Button>
                <Button
                  variant="outline"
                  onClick={() => navigate(`/package/${id}/manage`)}
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Manage
                </Button>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 border-blue-200 dark:border-blue-800">
                <CardContent className="pt-4 pb-4 text-center">
                  <div className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                    {mockPackage.materials.length}
                  </div>
                  <div className="text-xs text-blue-700 dark:text-blue-300">Materials</div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950 dark:to-green-900 border-green-200 dark:border-green-800">
                <CardContent className="pt-4 pb-4 text-center">
                  <div className="text-2xl font-bold text-green-900 dark:text-green-100">
                    {mockPackage.totalQuestions}
                  </div>
                  <div className="text-xs text-green-700 dark:text-green-300">Questions</div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950 dark:to-purple-900 border-purple-200 dark:border-purple-800">
                <CardContent className="pt-4 pb-4 text-center">
                  <div className="text-2xl font-bold text-purple-900 dark:text-purple-100">
                    {mockPackage.totalFlashcards}
                  </div>
                  <div className="text-xs text-purple-700 dark:text-purple-300">Flashcards</div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-950 dark:to-red-900 border-red-200 dark:border-red-800">
                <CardContent className="pt-4 pb-4 text-center">
                  <div className="text-2xl font-bold text-red-900 dark:text-red-100">
                    {mockPackage.totalLikes}
                  </div>
                  <div className="text-xs text-red-700 dark:text-red-300">Total Likes</div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>

        {/* Materials in Package */}
        <Card>
          <CardHeader>
            <CardTitle>Materials in this Package</CardTitle>
            <CardDescription>
              {mockPackage.materials.length} learning materials included
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockPackage.materials.map((material) => (
                <div
                  key={material.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <h3 className="font-semibold text-lg">{material.title}</h3>
                      <Badge
                        className={material.type === 'AI Generated'
                          ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                          : 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300'
                        }
                      >
                        {material.type}
                      </Badge>
                      {material.tags.map(tag => (
                        <Badge key={tag} variant="outline" className="text-xs bg-gray-100 dark:bg-gray-800">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                      <span>{material.questionsCount} Questions</span>
                      <span>{material.flashcardsCount} Flashcards</span>
                      <span className="flex items-center gap-1 text-red-500">
                        <Heart className="w-3 h-3" />
                        {material.likes} likes
                      </span>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    className="bg-indigo-600 hover:bg-indigo-700"
                    onClick={() => navigate(`/test/${material.id}`)}
                  >
                    <BookOpen className="w-4 h-4 mr-1" />
                    Start Test
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Action Button for Community Packages */}
        <div className="mt-6">
          <Button
            onClick={handleDownload}
            className="w-full h-12 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            <Download className="w-5 h-5 mr-2" />
            Add Entire Package to My Materials
          </Button>
        </div>
      </div>
    </div>
  );
}
