import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Brain, Upload, Plus, BookOpen, Users, LogOut, MessageSquare, Settings, Filter, Search, Edit, Trash2, Share2, Tag, Package, User, Heart, FolderPlus, Code } from 'lucide-react';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Label } from '../components/ui/label';
import { Checkbox } from '../components/ui/checkbox';
import { AIAssistant } from '../components/ai-assistant';
import { toast } from 'sonner';

// Enhanced mock data with tags, authors, likes, packages
const mockMaterials = [
  {
    id: '1',
    title: 'Introduction to React Hooks',
    type: 'AI Generated',
    questionsCount: 15,
    flashcardsCount: 20,
    date: '2026-03-28',
    shared: true,
    author: 'John Doe',
    tags: ['React', 'JavaScript', 'Frontend'],
    likes: 42,
    package: 'Web Development Basics',
    quizCode: 'RH2026',
  },
  {
    id: '2',
    title: 'JavaScript Fundamentals',
    type: 'Custom',
    questionsCount: 10,
    flashcardsCount: 15,
    date: '2026-03-25',
    shared: false,
    author: 'John Doe',
    tags: ['JavaScript', 'Programming'],
    likes: 28,
    package: 'Web Development Basics',
    quizCode: 'JSF2026',
  },
  {
    id: '3',
    title: 'CSS Grid and Flexbox',
    type: 'AI Generated',
    questionsCount: 12,
    flashcardsCount: 18,
    date: '2026-03-20',
    shared: true,
    author: 'John Doe',
    tags: ['CSS', 'Layout', 'Frontend'],
    likes: 35,
    package: null,
    quizCode: 'CSS2026',
  },
];

const mockPackages = [
  { id: 'pkg1', name: 'Web Development Basics', materialIds: ['1', '2'], tags: ['Web', 'Programming'] },
];

export function DashboardPage() {
  const navigate = useNavigate();
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [materials, setMaterials] = useState(mockMaterials);
  const [packages, setPackages] = useState(mockPackages);

  // Filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string>('all');
  const [selectedAuthor, setSelectedAuthor] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('date');
  const [filterType, setFilterType] = useState<string>('all'); // all, material, package

  // Dialog states
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [shareDialogMaterial, setShareDialogMaterial] = useState<any>(null);
  const [renameDialogOpen, setRenameDialogOpen] = useState(false);
  const [renameMaterial, setRenameMaterial] = useState<any>(null);
  const [newName, setNewName] = useState('');
  const [retagDialogOpen, setRetagDialogOpen] = useState(false);
  const [retagMaterial, setRetagMaterial] = useState<any>(null);
  const [newTags, setNewTags] = useState('');
  const [packageDialogOpen, setPackageDialogOpen] = useState(false);
  const [newPackageName, setNewPackageName] = useState('');
  const [newPackageTags, setNewPackageTags] = useState('');
  const [quizCodeDialogOpen, setQuizCodeDialogOpen] = useState(false);
  const [quizCodeSearch, setQuizCodeSearch] = useState('');

  // Share dialog states
  const [sharePublic, setSharePublic] = useState(true);
  const [shareUsers, setShareUsers] = useState<string[]>([]);

  // Get unique tags and authors
  const allTags = Array.from(new Set(materials.flatMap(m => m.tags)));
  const allAuthors = Array.from(new Set(materials.map(m => m.author)));

  // Filter and sort materials
  const filteredMaterials = materials
    .filter(m => {
      if (filterType === 'package') return false; // Show packages separately
      const matchesSearch = m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          m.quizCode.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesTag = selectedTag === 'all' || m.tags.includes(selectedTag);
      const matchesAuthor = selectedAuthor === 'all' || m.author === selectedAuthor;
      return matchesSearch && matchesTag && matchesAuthor;
    })
    .sort((a, b) => {
      if (sortBy === 'date') return new Date(b.date).getTime() - new Date(a.date).getTime();
      if (sortBy === 'name') return a.title.localeCompare(b.title);
      if (sortBy === 'tag') return (a.tags[0] || '').localeCompare(b.tags[0] || '');
      return 0;
    });

  const filteredPackages = filterType === 'all' || filterType === 'package' ? packages : [];

  const handleShare = (material: any) => {
    setShareDialogMaterial(material);
    setSharePublic(material.shared);
    setShareDialogOpen(true);
  };

  const confirmShare = () => {
    if (shareDialogMaterial) {
      setMaterials(materials.map(m =>
        m.id === shareDialogMaterial.id
          ? { ...m, shared: sharePublic }
          : m
      ));
      toast.success(`Sharing settings updated for "${shareDialogMaterial.title}"`);
      setShareDialogOpen(false);
    }
  };

  const handleRename = (material: any) => {
    setRenameMaterial(material);
    setNewName(material.title);
    setRenameDialogOpen(true);
  };

  const confirmRename = () => {
    if (renameMaterial && newName.trim()) {
      setMaterials(materials.map(m =>
        m.id === renameMaterial.id ? { ...m, title: newName } : m
      ));
      toast.success('Material renamed successfully');
      setRenameDialogOpen(false);
    }
  };

  const handleRetag = (material: any) => {
    setRetagMaterial(material);
    setNewTags(material.tags.join(', '));
    setRetagDialogOpen(true);
  };

  const confirmRetag = () => {
    if (retagMaterial) {
      const tags = newTags.split(',').map(t => t.trim()).filter(t => t);
      setMaterials(materials.map(m =>
        m.id === retagMaterial.id ? { ...m, tags } : m
      ));
      toast.success('Tags updated successfully');
      setRetagDialogOpen(false);
    }
  };

  const handleDelete = (materialId: string, title: string) => {
    if (confirm(`Are you sure you want to delete "${title}"?`)) {
      setMaterials(materials.filter(m => m.id !== materialId));
      toast.success('Material deleted successfully');
    }
  };

  const createPackage = () => {
    if (newPackageName.trim()) {
      const tags = newPackageTags.split(',').map(t => t.trim()).filter(t => t);
      const newPkg = {
        id: `pkg${Date.now()}`,
        name: newPackageName,
        materialIds: [],
        tags: tags
      };
      setPackages([...packages, newPkg]);
      toast.success(`Package "${newPackageName}" created`);
      setPackageDialogOpen(false);
      setNewPackageName('');
      setNewPackageTags('');
    }
  };

  const searchByQuizCode = () => {
    const found = materials.find(m => m.quizCode.toLowerCase() === quizCodeSearch.toLowerCase());
    if (found) {
      navigate(`/test/${found.id}`);
    } else {
      toast.error('Quiz code not found');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-2 rounded-lg">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-semibold">AI Learning Platform</span>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800 hover:bg-blue-100 dark:hover:bg-blue-900"
              onClick={() => setShowAIAssistant(true)}
            >
              <MessageSquare className="w-4 h-4 mr-2" />
              AI Assistant
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/profile')}
            >
              <User className="w-4 h-4 mr-2" />
              Profile
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/settings')}
            >
              <Settings className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate('/')}>
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 border-blue-200 dark:border-blue-800">
            <CardHeader className="pb-2">
              <CardDescription className="text-blue-700 dark:text-blue-300">Total Materials</CardDescription>
              <CardTitle className="text-3xl text-blue-900 dark:text-blue-100">3</CardTitle>
            </CardHeader>
          </Card>
          <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950 dark:to-green-900 border-green-200 dark:border-green-800">
            <CardHeader className="pb-2">
              <CardDescription className="text-green-700 dark:text-green-300">Questions Created</CardDescription>
              <CardTitle className="text-3xl text-green-900 dark:text-green-100">37</CardTitle>
            </CardHeader>
          </Card>
          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950 dark:to-purple-900 border-purple-200 dark:border-purple-800">
            <CardHeader className="pb-2">
              <CardDescription className="text-purple-700 dark:text-purple-300">Flashcards</CardDescription>
              <CardTitle className="text-3xl text-purple-900 dark:text-purple-100">53</CardTitle>
            </CardHeader>
          </Card>
          <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-950 dark:to-orange-900 border-orange-200 dark:border-orange-800">
            <CardHeader className="pb-2">
              <CardDescription className="text-orange-700 dark:text-orange-300">Tests Taken</CardDescription>
              <CardTitle className="text-3xl text-orange-900 dark:text-orange-100">12</CardTitle>
            </CardHeader>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Button
            onClick={() => navigate('/upload')}
            className="h-20 text-lg bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
          >
            <Upload className="w-5 h-5 mr-3" />
            Upload Material
          </Button>
          <Button
            onClick={() => navigate('/create')}
            className="h-20 text-lg bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"
          >
            <Plus className="w-5 h-5 mr-3" />
            Create Custom
          </Button>
          <Button
            onClick={() => setPackageDialogOpen(true)}
            className="h-20 text-lg bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800"
          >
            <FolderPlus className="w-5 h-5 mr-3" />
            Create Package
          </Button>
          <Button
            onClick={() => navigate('/library')}
            className="h-20 text-lg bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800"
          >
            <Users className="w-5 h-5 mr-3" />
            Community
          </Button>
        </div>

        {/* Quick Quiz Code Access */}
        <Card className="mb-6 border-indigo-200 dark:border-indigo-800">
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <div className="flex-1">
                <Input
                  placeholder="Enter quiz code for quick access (e.g., RH2026)"
                  value={quizCodeSearch}
                  onChange={(e) => setQuizCodeSearch(e.target.value)}
                  className="h-12"
                />
              </div>
              <Button onClick={searchByQuizCode} className="h-12 bg-indigo-600 hover:bg-indigo-700">
                <Code className="w-4 h-4 mr-2" />
                Go to Quiz
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Filters and Search */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div className="md:col-span-2">
                <Input
                  placeholder="Search materials..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full"
                />
              </div>
              <Select value={selectedTag} onValueChange={setSelectedTag}>
                <SelectTrigger>
                  <SelectValue placeholder="Select tag" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Tags</SelectItem>
                  {allTags.map(tag => (
                    <SelectItem key={tag} value={tag}>{tag}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="date">Sort by: Date</SelectItem>
                  <SelectItem value="name">Sort by: Name</SelectItem>
                  <SelectItem value="tag">Sort by: Tag</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Items</SelectItem>
                  <SelectItem value="material">Materials Only</SelectItem>
                  <SelectItem value="package">Packages Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Packages */}
        {filteredPackages.length > 0 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5" />
                Your Packages
              </CardTitle>
              <CardDescription>Organized collections of learning materials</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {filteredPackages.map((pkg) => (
                  <div
                    key={pkg.id}
                    className="flex items-center justify-between p-4 border-2 border-purple-200 dark:border-purple-800 rounded-lg bg-purple-50 dark:bg-purple-950/30"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Package className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                        <h3 className="font-semibold text-lg">{pkg.name}</h3>
                        <Badge className="bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300">
                          Package
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                        <span>{pkg.materialIds.length} Materials</span>
                        {pkg.tags.map(tag => (
                          <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => navigate(`/package/${pkg.id}/manage`)}
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        Manage
                      </Button>
                      <Button
                        size="sm"
                        className="bg-purple-600 hover:bg-purple-700"
                        onClick={() => navigate(`/package/${pkg.id}`)}
                      >
                        <BookOpen className="w-4 h-4 mr-1" />
                        View
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Materials List */}
        <Card>
          <CardHeader>
            <CardTitle>Your Learning Materials</CardTitle>
            <CardDescription>
              Materials you've created or generated with AI
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {filteredMaterials.map((material) => (
                <div
                  key={material.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <h3 className="font-semibold text-lg">{material.title}</h3>
                      <Badge
                        className={material.type === 'AI Generated'
                          ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                          : 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300'
                        }
                      >
                        {material.type}
                      </Badge>
                      {material.shared && (
                        <Badge className="bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300">
                          <Users className="w-3 h-3 mr-1" />
                          Shared
                        </Badge>
                      )}
                      {material.tags.map(tag => (
                        <Badge key={tag} variant="outline" className="text-xs bg-gray-100 dark:bg-gray-800">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400 mb-2">
                      <span>{material.questionsCount} Questions</span>
                      <span>{material.flashcardsCount} Flashcards</span>
                      <span>Created: {material.date}</span>
                      <span className="flex items-center gap-1">
                        <Heart className="w-3 h-3" />
                        {material.likes} likes
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-500">
                      Code: {material.quizCode}
                      {material.package && ` • Package: ${material.package}`}
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 ml-4">
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => navigate(`/test/${material.id}`)}
                        className="bg-indigo-600 hover:bg-indigo-700"
                      >
                        <BookOpen className="w-4 h-4 mr-1" />
                        Start Test
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleShare(material)}
                      >
                        <Share2 className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => navigate(`/material/${material.id}/modify`)}
                      >
                        <Edit className="w-3 h-3" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleRename(material)}
                      >
                        Rename
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleRetag(material)}
                      >
                        <Tag className="w-3 h-3" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-red-600 hover:text-red-700 dark:text-red-400"
                        onClick={() => handleDelete(material.id, material.title)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Share Dialog */}
      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share Material</DialogTitle>
            <DialogDescription>
              Choose how you want to share "{shareDialogMaterial?.title}"
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="public"
                checked={sharePublic}
                onCheckedChange={(checked) => setSharePublic(checked as boolean)}
              />
              <Label htmlFor="public">Make public in community library</Label>
            </div>
            {!sharePublic && (
              <div className="space-y-2">
                <Label>Share with specific users (coming soon)</Label>
                <Input placeholder="Enter usernames or emails" disabled />
              </div>
            )}
            <div className="p-3 bg-gray-100 dark:bg-gray-800 rounded">
              <Label className="text-sm text-gray-600 dark:text-gray-400">Quiz Code</Label>
              <p className="font-mono text-lg font-semibold">{shareDialogMaterial?.quizCode}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Share this code for quick access</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShareDialogOpen(false)}>Cancel</Button>
            <Button onClick={confirmShare} className="bg-indigo-600 hover:bg-indigo-700">Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rename Dialog */}
      <Dialog open={renameDialogOpen} onOpenChange={setRenameDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rename Material</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="newName">New Name</Label>
              <Input
                id="newName"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="Enter new name"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRenameDialogOpen(false)}>Cancel</Button>
            <Button onClick={confirmRename} className="bg-indigo-600 hover:bg-indigo-700">Rename</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Retag Dialog */}
      <Dialog open={retagDialogOpen} onOpenChange={setRetagDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Tags</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="newTags">Tags (comma-separated)</Label>
              <Input
                id="newTags"
                value={newTags}
                onChange={(e) => setNewTags(e.target.value)}
                placeholder="e.g., React, JavaScript, Frontend"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRetagDialogOpen(false)}>Cancel</Button>
            <Button onClick={confirmRetag} className="bg-indigo-600 hover:bg-indigo-700">Update</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Package Dialog */}
      <Dialog open={packageDialogOpen} onOpenChange={setPackageDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Package</DialogTitle>
            <DialogDescription>
              Organize your materials into collections
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="packageName">Package Name</Label>
              <Input
                id="packageName"
                value={newPackageName}
                onChange={(e) => setNewPackageName(e.target.value)}
                placeholder="e.g., Web Development Basics"
              />
            </div>
            <div>
              <Label htmlFor="packageTags">Tags (comma-separated)</Label>
              <Input
                id="packageTags"
                value={newPackageTags}
                onChange={(e) => setNewPackageTags(e.target.value)}
                placeholder="e.g., Web, Programming, Frontend"
              />
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Add tags to help categorize this package
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPackageDialogOpen(false)}>Cancel</Button>
            <Button onClick={createPackage} className="bg-purple-600 hover:bg-purple-700">Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* AI Assistant */}
      {showAIAssistant && (
        <AIAssistant onClose={() => setShowAIAssistant(false)} />
      )}
    </div>
  );
}
