import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Brain, ArrowLeft, User, BookOpen, FileQuestion, Award, Users, Bell, BellOff, Heart, Package } from 'lucide-react';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { toast } from 'sonner';

// Mock user data
const mockUsers = {
  'me': {
    id: 'me',
    name: 'John Doe',
    username: '@johndoe',
    avatar: '',
    bio: 'Passionate learner and educator. Love creating quality learning materials!',
    totalMaterials: 12,
    totalQuizzes: 8,
    totalQuestions: 156,
    followers: 234,
    following: 89,
    isOwnProfile: true,
  },
  'user1': {
    id: 'user1',
    name: 'Sarah Chen',
    username: '@sarahchen',
    avatar: '',
    bio: 'Python expert and data science enthusiast. Teaching programming for 5+ years.',
    totalMaterials: 28,
    totalQuizzes: 15,
    totalQuestions: 420,
    followers: 1842,
    following: 156,
    isOwnProfile: false,
  },
  'user3': {
    id: 'user3',
    name: 'Emily Johnson',
    username: '@emilyj',
    avatar: '',
    bio: 'AI/ML researcher. Creating educational content to make complex topics accessible.',
    totalMaterials: 35,
    totalQuizzes: 22,
    totalQuestions: 580,
    followers: 2941,
    following: 203,
    isOwnProfile: false,
  },
};

const mockMaterials = [
  {
    id: '1',
    title: 'Introduction to React Hooks',
    type: 'AI Generated',
    questionsCount: 15,
    flashcardsCount: 20,
    likes: 42,
    tags: ['React', 'JavaScript'],
  },
  {
    id: '2',
    title: 'JavaScript Fundamentals',
    type: 'Custom',
    questionsCount: 10,
    flashcardsCount: 15,
    likes: 28,
    tags: ['JavaScript'],
  },
];

export function ProfilePage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const userId = id || 'me';
  const user = mockUsers[userId as keyof typeof mockUsers] || mockUsers.me;

  const [isFollowing, setIsFollowing] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  const handleFollow = () => {
    setIsFollowing(!isFollowing);
    toast.success(isFollowing ? `Unfollowed ${user.name}` : `Following ${user.name}`);
  };

  const handleNotifications = () => {
    if (!isFollowing) {
      toast.error('You need to follow this user first');
      return;
    }
    setNotificationsEnabled(!notificationsEnabled);
    toast.success(notificationsEnabled
      ? 'Notifications disabled'
      : 'You will be notified when this user creates new content'
    );
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-2 rounded-lg">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-semibold">User Profile</span>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Profile Header */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              {/* Avatar */}
              <Avatar className="w-32 h-32">
                <AvatarImage src={user.avatar} />
                <AvatarFallback className="text-3xl bg-gradient-to-br from-indigo-500 to-purple-500 text-white">
                  {getInitials(user.name)}
                </AvatarFallback>
              </Avatar>

              {/* User Info */}
              <div className="flex-1">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h1 className="text-3xl font-bold mb-1">{user.name}</h1>
                    <p className="text-gray-600 dark:text-gray-400">{user.username}</p>
                  </div>
                  {!user.isOwnProfile && (
                    <div className="flex gap-2">
                      <Button
                        onClick={handleFollow}
                        className={isFollowing
                          ? 'bg-gray-600 hover:bg-gray-700'
                          : 'bg-indigo-600 hover:bg-indigo-700'
                        }
                      >
                        <Users className="w-4 h-4 mr-2" />
                        {isFollowing ? 'Following' : 'Follow'}
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={handleNotifications}
                        className={notificationsEnabled ? 'text-indigo-600' : ''}
                      >
                        {notificationsEnabled ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                      </Button>
                    </div>
                  )}
                  {user.isOwnProfile && (
                    <Button
                      variant="outline"
                      onClick={() => navigate('/profile/edit')}
                    >
                      Edit Profile
                    </Button>
                  )}
                </div>

                <p className="text-gray-700 dark:text-gray-300 mb-4">{user.bio}</p>

                {/* Stats */}
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  <Card className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
                    <CardContent className="pt-4 pb-4 text-center">
                      <BookOpen className="w-6 h-6 mx-auto mb-2 text-blue-600 dark:text-blue-400" />
                      <div className="text-2xl font-bold text-blue-900 dark:text-blue-100">{user.totalMaterials}</div>
                      <div className="text-xs text-blue-700 dark:text-blue-300">Materials</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
                    <CardContent className="pt-4 pb-4 text-center">
                      <Award className="w-6 h-6 mx-auto mb-2 text-green-600 dark:text-green-400" />
                      <div className="text-2xl font-bold text-green-900 dark:text-green-100">{user.totalQuizzes}</div>
                      <div className="text-xs text-green-700 dark:text-green-300">Quizzes</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-purple-50 dark:bg-purple-950 border-purple-200 dark:border-purple-800">
                    <CardContent className="pt-4 pb-4 text-center">
                      <FileQuestion className="w-6 h-6 mx-auto mb-2 text-purple-600 dark:text-purple-400" />
                      <div className="text-2xl font-bold text-purple-900 dark:text-purple-100">{user.totalQuestions}</div>
                      <div className="text-xs text-purple-700 dark:text-purple-300">Questions</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-orange-50 dark:bg-orange-950 border-orange-200 dark:border-orange-800">
                    <CardContent className="pt-4 pb-4 text-center">
                      <Users className="w-6 h-6 mx-auto mb-2 text-orange-600 dark:text-orange-400" />
                      <div className="text-2xl font-bold text-orange-900 dark:text-orange-100">{user.followers}</div>
                      <div className="text-xs text-orange-700 dark:text-orange-300">Followers</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-pink-50 dark:bg-pink-950 border-pink-200 dark:border-pink-800">
                    <CardContent className="pt-4 pb-4 text-center">
                      <Users className="w-6 h-6 mx-auto mb-2 text-pink-600 dark:text-pink-400" />
                      <div className="text-2xl font-bold text-pink-900 dark:text-pink-100">{user.following}</div>
                      <div className="text-xs text-pink-700 dark:text-pink-300">Following</div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Content Tabs */}
        <Tabs defaultValue="materials" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="materials">Materials</TabsTrigger>
            <TabsTrigger value="packages">Packages</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="materials" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Published Materials</CardTitle>
                <CardDescription>
                  {user.isOwnProfile ? 'Your' : `${user.name}'s`} shared learning materials
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockMaterials.map((material) => (
                    <div
                      key={material.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                          <h3 className="font-semibold">{material.title}</h3>
                          <Badge
                            className={material.type === 'AI Generated'
                              ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                              : 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300'
                            }
                          >
                            {material.type}
                          </Badge>
                          {material.tags.map(tag => (
                            <Badge key={tag} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                        <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                          <span>{material.questionsCount} Questions</span>
                          <span>{material.flashcardsCount} Flashcards</span>
                          <span className="flex items-center gap-1 text-red-500">
                            <Heart className="w-3 h-3" />
                            {material.likes} likes
                          </span>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className="bg-indigo-600 hover:bg-indigo-700"
                        onClick={() => navigate(`/test/${material.id}`)}
                      >
                        <BookOpen className="w-4 h-4 mr-1" />
                        View
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="packages" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Packages</CardTitle>
                <CardDescription>
                  {user.isOwnProfile ? 'Your' : `${user.name}'s`} material packages
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-gray-500 dark:text-gray-400">
                  <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No packages created yet</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="activity" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>
                  {user.isOwnProfile ? 'Your' : `${user.name}'s`} recent activity
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 border rounded-lg">
                    <div className="w-2 h-2 rounded-full bg-green-500"></div>
                    <div className="flex-1">
                      <p className="text-sm">Created new material: "Introduction to React Hooks"</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">2 days ago</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 border rounded-lg">
                    <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                    <div className="flex-1">
                      <p className="text-sm">Received 15 new likes on materials</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">4 days ago</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 border rounded-lg">
                    <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                    <div className="flex-1">
                      <p className="text-sm">Created package "Web Development Basics"</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">1 week ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
