import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Brain, ArrowLeft, Plus, X, Save, Share2, Sparkles, Send } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Switch } from '../components/ui/switch';
import { toast } from 'sonner';

interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
}

interface Flashcard {
  front: string;
  back: string;
}

export function CreateQuestionPage() {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [tags, setTags] = useState('');
  const [shareEnabled, setShareEnabled] = useState(false);
  const [aiRequest, setAiRequest] = useState('');
  const [aiProcessing, setAiProcessing] = useState(false);

  // Questions
  const [questions, setQuestions] = useState<Question[]>([
    { question: '', options: ['', '', '', ''], correctAnswer: 0 },
  ]);

  // Flashcards
  const [flashcards, setFlashcards] = useState<Flashcard[]>([
    { front: '', back: '' },
  ]);

  const addQuestion = () => {
    setQuestions([...questions, { question: '', options: ['', '', '', ''], correctAnswer: 0 }]);
  };

  const removeQuestion = (index: number) => {
    setQuestions(questions.filter((_, i) => i !== index));
  };

  const updateQuestion = (index: number, field: keyof Question, value: any) => {
    const updated = [...questions];
    updated[index] = { ...updated[index], [field]: value };
    setQuestions(updated);
  };

  const updateQuestionOption = (qIndex: number, oIndex: number, value: string) => {
    const updated = [...questions];
    updated[qIndex].options[oIndex] = value;
    setQuestions(updated);
  };

  const addFlashcard = () => {
    setFlashcards([...flashcards, { front: '', back: '' }]);
  };

  const removeFlashcard = (index: number) => {
    setFlashcards(flashcards.filter((_, i) => i !== index));
  };

  const updateFlashcard = (index: number, field: keyof Flashcard, value: string) => {
    const updated = [...flashcards];
    updated[index] = { ...updated[index], [field]: value };
    setFlashcards(updated);
  };

  const handleSave = () => {
    if (!title) {
      toast.error('Please provide a title');
      return;
    }
    toast.success('Material saved successfully!');
    navigate('/dashboard');
  };

  const handleAIRequest = () => {
    if (!aiRequest.trim()) {
      toast.error('Please enter a request for the AI');
      return;
    }
    setAiProcessing(true);
    toast.info('Processing your AI request...');

    // Simulate AI processing
    setTimeout(() => {
      setAiProcessing(false);
      toast.success('AI has generated content based on your request!');
      setAiRequest('');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate('/dashboard')}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-lg">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-semibold">AI Learning Platform</span>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Create Custom Learning Material</CardTitle>
            <CardDescription>
              Manually create questions and flashcards for your learning materials
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Material Title</Label>
              <Input
                id="title"
                placeholder="e.g., JavaScript Fundamentals"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tags">Tags (comma-separated)</Label>
              <Input
                id="tags"
                placeholder="e.g., JavaScript, Programming, Basics"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
              />
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Add tags to help categorize your material
              </p>
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Share with community</Label>
                <p className="text-sm text-gray-500">
                  Allow others to view and use your material
                </p>
              </div>
              <Switch checked={shareEnabled} onCheckedChange={setShareEnabled} />
            </div>
          </CardContent>
        </Card>

        {/* AI Request Box */}
        <Card className="mb-6 border-indigo-200 dark:border-indigo-800 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <CardTitle>AI Assistant</CardTitle>
            </div>
            <CardDescription>
              Ask the AI to help you create questions, flashcards, or improve your content
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Textarea
                placeholder="e.g., Generate 5 multiple choice questions about React hooks, Create flashcards for JavaScript array methods, Improve my existing questions..."
                value={aiRequest}
                onChange={(e) => setAiRequest(e.target.value)}
                className="flex-1 min-h-[80px] bg-white dark:bg-gray-900"
                disabled={aiProcessing}
              />
              <Button
                onClick={handleAIRequest}
                disabled={aiProcessing}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
              >
                {aiProcessing ? (
                  <>
                    <div className="animate-spin w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full" />
                    Processing
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Ask AI
                  </>
                )}
              </Button>
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-2">
              💡 Tip: Be specific with your request for better results
            </p>
          </CardContent>
        </Card>

        <Tabs defaultValue="questions" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="questions">
              Questions ({questions.length})
            </TabsTrigger>
            <TabsTrigger value="flashcards">
              Flashcards ({flashcards.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="questions" className="space-y-4">
            {questions.map((q, qIndex) => (
              <Card key={qIndex}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Question {qIndex + 1}</CardTitle>
                    {questions.length > 1 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeQuestion(qIndex)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Question</Label>
                    <Textarea
                      placeholder="Enter your question here..."
                      value={q.question}
                      onChange={(e) => updateQuestion(qIndex, 'question', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Answer Options</Label>
                    <div className="space-y-2">
                      {q.options.map((option, oIndex) => (
                        <div key={oIndex} className="flex items-center gap-2">
                          <input
                            type="radio"
                            name={`correct-${qIndex}`}
                            checked={q.correctAnswer === oIndex}
                            onChange={() => updateQuestion(qIndex, 'correctAnswer', oIndex)}
                            className="w-4 h-4"
                          />
                          <Input
                            placeholder={`Option ${oIndex + 1}`}
                            value={option}
                            onChange={(e) => updateQuestionOption(qIndex, oIndex, e.target.value)}
                          />
                        </div>
                      ))}
                    </div>
                    <p className="text-xs text-gray-500">
                      Select the radio button for the correct answer
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
            <Button onClick={addQuestion} variant="outline" className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              Add Question
            </Button>
          </TabsContent>

          <TabsContent value="flashcards" className="space-y-4">
            {flashcards.map((card, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Flashcard {index + 1}</CardTitle>
                    {flashcards.length > 1 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFlashcard(index)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Front (Question/Concept)</Label>
                    <Textarea
                      placeholder="Enter the question or concept..."
                      value={card.front}
                      onChange={(e) => updateFlashcard(index, 'front', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Back (Answer/Definition)</Label>
                    <Textarea
                      placeholder="Enter the answer or definition..."
                      value={card.back}
                      onChange={(e) => updateFlashcard(index, 'back', e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            ))}
            <Button onClick={addFlashcard} variant="outline" className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              Add Flashcard
            </Button>
          </TabsContent>
        </Tabs>

        <div className="flex gap-3 mt-6">
          <Button onClick={handleSave} className="flex-1">
            <Save className="w-4 h-4 mr-2" />
            Save Material
          </Button>
          {shareEnabled && (
            <Button variant="outline">
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
