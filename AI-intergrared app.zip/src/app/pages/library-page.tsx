import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Brain, ArrowLeft, Search, Download, Star, Users, Heart, Package, User } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { toast } from 'sonner';

// Mock community materials
const mockCommunityMaterials = [
  {
    id: 'c1',
    title: 'Advanced Python Programming',
    author: 'Sarah Chen',
    authorId: 'user1',
    questionsCount: 25,
    flashcardsCount: 30,
    rating: 4.8,
    downloads: 1234,
    likes: 256,
    tags: ['Python', 'Programming', 'Advanced'],
    package: 'Python Mastery',
    type: 'material',
  },
  {
    id: 'c2',
    title: 'Web Development Basics',
    author: 'John Smith',
    authorId: 'user2',
    questionsCount: 20,
    flashcardsCount: 25,
    rating: 4.5,
    downloads: 892,
    likes: 189,
    tags: ['HTML', 'CSS', 'JavaScript'],
    package: null,
    type: 'material',
  },
  {
    id: 'c3',
    title: 'Machine Learning Fundamentals',
    author: 'Emily Johnson',
    authorId: 'user3',
    questionsCount: 30,
    flashcardsCount: 40,
    rating: 4.9,
    downloads: 2341,
    likes: 412,
    tags: ['ML', 'AI', 'Data Science'],
    package: 'AI & ML Complete',
    type: 'material',
  },
  {
    id: 'c4',
    title: 'Database Design Principles',
    author: 'Michael Brown',
    authorId: 'user4',
    questionsCount: 18,
    flashcardsCount: 22,
    rating: 4.6,
    downloads: 567,
    likes: 134,
    tags: ['SQL', 'Database', 'Design'],
    package: null,
    type: 'material',
  },
  {
    id: 'c5',
    title: 'React Performance Optimization',
    author: 'Lisa Wang',
    authorId: 'user5',
    questionsCount: 15,
    flashcardsCount: 20,
    rating: 4.7,
    downloads: 1089,
    likes: 298,
    tags: ['React', 'Performance', 'Frontend'],
    package: 'React Advanced',
    type: 'material',
  },
];

const mockCommunityPackages = [
  {
    id: 'pkg1',
    name: 'Python Mastery',
    author: 'Sarah Chen',
    authorId: 'user1',
    materialsCount: 5,
    totalQuestions: 120,
    likes: 567,
    downloads: 2341,
    tags: ['Python', 'Programming'],
    type: 'package',
  },
  {
    id: 'pkg2',
    name: 'AI & ML Complete',
    author: 'Emily Johnson',
    authorId: 'user3',
    materialsCount: 8,
    totalQuestions: 200,
    likes: 892,
    downloads: 4123,
    tags: ['AI', 'ML', 'Data Science'],
    type: 'package',
  },
  {
    id: 'pkg3',
    name: 'React Advanced',
    author: 'Lisa Wang',
    authorId: 'user5',
    materialsCount: 6,
    totalQuestions: 90,
    likes: 445,
    downloads: 1890,
    tags: ['React', 'Frontend', 'JavaScript'],
    type: 'package',
  },
];

export function LibraryPage() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string>('all');
  const [selectedAuthor, setSelectedAuthor] = useState<string>('all');
  const [contentType, setContentType] = useState<string>('all'); // all, material, package
  const [likedMaterials, setLikedMaterials] = useState<Set<string>>(new Set());

  // Get all unique tags and authors
  const allTags = Array.from(new Set([
    ...mockCommunityMaterials.flatMap(m => m.tags),
    ...mockCommunityPackages.flatMap(p => p.tags)
  ]));
  const allAuthors = Array.from(new Set([
    ...mockCommunityMaterials.map(m => m.author),
    ...mockCommunityPackages.map(p => p.author)
  ]));

  // Filter materials
  const filteredMaterials = mockCommunityMaterials.filter((material) => {
    if (contentType === 'package') return false;
    const query = searchQuery.toLowerCase();
    const matchesSearch = material.title.toLowerCase().includes(query) ||
                         material.author.toLowerCase().includes(query) ||
                         material.tags.some(tag => tag.toLowerCase().includes(query));
    return matchesSearch;
  });

  // Filter packages
  const filteredPackages = mockCommunityPackages.filter((pkg) => {
    if (contentType === 'material') return false;
    const query = searchQuery.toLowerCase();
    const matchesSearch = pkg.name.toLowerCase().includes(query) ||
                         pkg.author.toLowerCase().includes(query) ||
                         pkg.tags.some(tag => tag.toLowerCase().includes(query));
    return matchesSearch;
  });

  const handleDownload = (itemId: string, title: string, type: string) => {
    toast.success(`"${title}" added to your ${type === 'package' ? 'packages' : 'materials'}!`);
  };

  const handleLike = (itemId: string) => {
    setLikedMaterials(prev => {
      const newSet = new Set(prev);
      if (newSet.has(itemId)) {
        newSet.delete(itemId);
      } else {
        newSet.add(itemId);
      }
      return newSet;
    });
  };

  const viewAuthorProfile = (authorId: string, authorName: string) => {
    navigate(`/profile/${authorId}`);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <header className="bg-white dark:bg-gray-900 border-b dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate('/dashboard')}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-2 rounded-lg">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-semibold">Community Library</span>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Search and Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Discover Shared Materials</CardTitle>
            <CardDescription>
              Browse and download learning materials and packages shared by the community
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                placeholder="Search by title, tag, or author..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Select value={contentType} onValueChange={setContentType}>
                <SelectTrigger>
                  <SelectValue placeholder="Content type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Content</SelectItem>
                  <SelectItem value="material">Materials Only</SelectItem>
                  <SelectItem value="package">Packages Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Packages Section */}
        {filteredPackages.length > 0 && (contentType === 'all' || contentType === 'package') && (
          <div className="mb-8">
            <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
              <Package className="w-6 h-6 text-purple-600 dark:text-purple-400" />
              Packages
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredPackages.map((pkg) => (
                <Card key={pkg.id} className="hover:shadow-lg transition-shadow border-purple-200 dark:border-purple-800">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Package className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                          <CardTitle>{pkg.name}</CardTitle>
                          <Badge className="bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300">
                            Package
                          </Badge>
                        </div>
                        <CardDescription
                          className="flex items-center gap-2 cursor-pointer hover:underline"
                          onClick={() => viewAuthorProfile(pkg.authorId, pkg.author)}
                        >
                          <User className="w-4 h-4" />
                          {pkg.author}
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-1 text-yellow-500">
                        <Star className="w-4 h-4 fill-current" />
                        <span className="text-sm font-medium">{pkg.downloads}</span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                      <span>{pkg.materialsCount} Materials</span>
                      <span>{pkg.totalQuestions} Questions</span>
                      <span className="flex items-center gap-1 text-red-500">
                        <Heart className={`w-4 h-4 ${likedMaterials.has(pkg.id) ? 'fill-current' : ''}`} />
                        {pkg.likes}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {pkg.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="bg-purple-50 dark:bg-purple-950">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        className="flex-1 bg-purple-600 hover:bg-purple-700"
                        onClick={() => handleDownload(pkg.id, pkg.name, 'package')}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Add Package
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleLike(pkg.id)}
                        className={likedMaterials.has(pkg.id) ? 'text-red-500' : ''}
                      >
                        <Heart className={`w-4 h-4 ${likedMaterials.has(pkg.id) ? 'fill-current' : ''}`} />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Materials Section */}
        {filteredMaterials.length > 0 && (contentType === 'all' || contentType === 'material') && (
          <div>
            <h2 className="text-2xl font-semibold mb-4">Materials</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredMaterials.map((material) => (
                <Card key={material.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="mb-2">{material.title}</CardTitle>
                        <CardDescription
                          className="flex items-center gap-2 cursor-pointer hover:underline"
                          onClick={() => viewAuthorProfile(material.authorId, material.author)}
                        >
                          <User className="w-4 h-4" />
                          {material.author}
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-1 text-yellow-500">
                        <Star className="w-4 h-4 fill-current" />
                        <span className="text-sm font-medium">{material.rating}</span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                      <span>{material.questionsCount} Questions</span>
                      <span>{material.flashcardsCount} Flashcards</span>
                      <span className="flex items-center gap-1 text-red-500">
                        <Heart className={`w-4 h-4 ${likedMaterials.has(material.id) ? 'fill-current' : ''}`} />
                        {material.likes}
                      </span>
                    </div>
                    {material.package && (
                      <div className="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-1">
                        <Package className="w-3 h-3" />
                        Part of: {material.package}
                      </div>
                    )}
                    <div className="flex flex-wrap gap-2">
                      {material.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                        onClick={() => handleDownload(material.id, material.title, 'material')}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Add to My Materials
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleLike(material.id)}
                        className={likedMaterials.has(material.id) ? 'text-red-500' : ''}
                      >
                        <Heart className={`w-4 h-4 ${likedMaterials.has(material.id) ? 'fill-current' : ''}`} />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {filteredMaterials.length === 0 && filteredPackages.length === 0 && (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-gray-500 dark:text-gray-400">No content found matching your filters.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
