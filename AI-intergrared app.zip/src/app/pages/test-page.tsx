import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Brain, ArrowLeft, Clock, ChevronRight, RotateCcw } from 'lucide-react';
import { Progress } from '../components/ui/progress';
import { Badge } from '../components/ui/badge';
import { AIExplanationDialog } from '../components/ai-explanation-dialog';
import { FlashcardViewer } from '../components/flashcard-viewer';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';

// Mock data
const mockQuestions = [
  {
    id: '1',
    question: 'What is the main purpose of React Hooks?',
    options: [
      'To add animations to components',
      'To use state and other React features without writing a class',
      'To create CSS styles',
      'To handle routing in React applications',
    ],
    correctAnswer: 1,
  },
  {
    id: '2',
    question: 'Which hook is used for side effects in React?',
    options: ['useState', 'useEffect', 'useContext', 'useReducer'],
    correctAnswer: 1,
  },
  {
    id: '3',
    question: 'What does the useState hook return?',
    options: [
      'A single value',
      'An object with state',
      'An array with the current state and a function to update it',
      'A callback function',
    ],
    correctAnswer: 2,
  },
];

const mockFlashcards = [
  {
    id: '1',
    front: 'What is useState?',
    back: 'useState is a Hook that lets you add React state to function components. It returns a pair: the current state value and a function to update it.',
  },
  {
    id: '2',
    front: 'What is useEffect?',
    back: 'useEffect is a Hook that performs side effects in function components. It serves the same purpose as componentDidMount, componentDidUpdate, and componentWillUnmount combined.',
  },
  {
    id: '3',
    front: 'What is useContext?',
    back: 'useContext is a Hook that accepts a context object and returns the current context value for that context. It allows you to subscribe to React context without introducing nesting.',
  },
];

export function TestPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [mode, setMode] = useState<'questions' | 'flashcards'>('questions');
  
  // Question mode state
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<(number | null)[]>(
    new Array(mockQuestions.length).fill(null)
  );
  const [showResults, setShowResults] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(600); // 10 minutes in seconds
  const [timerActive, setTimerActive] = useState(true);
  const [showExplanation, setShowExplanation] = useState(false);
  const [explanationQuestion, setExplanationQuestion] = useState<string>('');
  const [explanationCorrect, setExplanationCorrect] = useState<string>('');
  const [explanationSelected, setExplanationSelected] = useState<string>('');

  useEffect(() => {
    if (timerActive && !showResults && timeRemaining > 0) {
      const timer = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            setTimerActive(false);
            handleSubmit();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [timerActive, showResults, timeRemaining]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerSelect = (answerIndex: number) => {
    if (showResults) return;
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleSubmit = () => {
    setTimerActive(false);
    setShowResults(true);
  };

  const handleRestart = () => {
    setCurrentQuestion(0);
    setSelectedAnswers(new Array(mockQuestions.length).fill(null));
    setShowResults(false);
    setTimeRemaining(600);
    setTimerActive(true);
  };

  const handleExplainAnswer = (questionIndex: number) => {
    const question = mockQuestions[questionIndex];
    const selectedAnswer = selectedAnswers[questionIndex];
    setExplanationQuestion(question.question);
    setExplanationCorrect(question.options[question.correctAnswer]);
    setExplanationSelected(
      selectedAnswer !== null ? question.options[selectedAnswer] : 'No answer selected'
    );
    setShowExplanation(true);
  };

  const score = selectedAnswers.filter(
    (answer, index) => answer === mockQuestions[index].correctAnswer
  ).length;

  const progressPercentage = ((currentQuestion + 1) / mockQuestions.length) * 100;

  if (showResults) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
        <header className="bg-white dark:bg-gray-900 border-b dark:border-gray-800">
          <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="bg-indigo-600 p-2 rounded-lg">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-semibold">Test Results</span>
            </div>
          </div>
        </header>

        <div className="max-w-4xl mx-auto px-4 py-8">
          <Card className="mb-6">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl">
                Your Score: {score}/{mockQuestions.length}
              </CardTitle>
              <CardDescription>
                {score === mockQuestions.length
                  ? 'Perfect score! Excellent work!'
                  : score >= mockQuestions.length * 0.7
                  ? 'Great job! You passed!'
                  : 'Keep practicing to improve!'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Progress value={(score / mockQuestions.length) * 100} className="mb-4" />
              <div className="flex gap-3">
                <Button onClick={handleRestart} variant="outline" className="flex-1">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Retake Test
                </Button>
                <Button onClick={() => navigate('/dashboard')} className="flex-1">
                  Back to Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Review Answers</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {mockQuestions.map((question, index) => {
                const isCorrect = selectedAnswers[index] === question.correctAnswer;
                return (
                  <div key={question.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h4 className="font-medium mb-2">
                          {index + 1}. {question.question}
                        </h4>
                      </div>
                      <Badge variant={isCorrect ? 'default' : 'destructive'}>
                        {isCorrect ? 'Correct' : 'Wrong'}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      {question.options.map((option, optionIndex) => {
                        const isSelected = selectedAnswers[index] === optionIndex;
                        const isCorrectOption = question.correctAnswer === optionIndex;
                        return (
                          <div
                            key={optionIndex}
                            className={`p-3 rounded ${
                              isCorrectOption
                                ? 'bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800'
                                : isSelected
                                ? 'bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800'
                                : 'bg-gray-50 dark:bg-gray-800'
                            }`}
                          >
                            {option}
                            {isCorrectOption && (
                              <span className="ml-2 text-green-600 dark:text-green-400 text-sm">✓ Correct</span>
                            )}
                            {isSelected && !isCorrectOption && (
                              <span className="ml-2 text-red-600 dark:text-red-400 text-sm">✗ Your answer</span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                    {!isCorrect && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-3"
                        onClick={() => handleExplainAnswer(index)}
                      >
                        Ask AI: Why is this wrong?
                      </Button>
                    )}
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </div>

        <AIExplanationDialog
          open={showExplanation}
          onClose={() => setShowExplanation(false)}
          question={explanationQuestion}
          correctAnswer={explanationCorrect}
          selectedAnswer={explanationSelected}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <header className="bg-white dark:bg-gray-900 border-b dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="bg-indigo-600 p-2 rounded-lg">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-semibold">Test Mode</span>
            </div>
          </div>
          <div className="flex items-center gap-2 text-lg font-semibold">
            <Clock className="w-5 h-5" />
            <span className={timeRemaining < 60 ? 'text-red-600 dark:text-red-400' : ''}>
              {formatTime(timeRemaining)}
            </span>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <Tabs value={mode} onValueChange={(v) => setMode(v as any)} className="mb-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="questions">Questions</TabsTrigger>
            <TabsTrigger value="flashcards">Flashcards</TabsTrigger>
          </TabsList>

          <TabsContent value="questions" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">
                    Question {currentQuestion + 1} of {mockQuestions.length}
                  </CardTitle>
                  <Badge variant="outline">{Math.round(progressPercentage)}% Complete</Badge>
                </div>
                <Progress value={progressPercentage} />
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl">
                  {mockQuestions[currentQuestion].question}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {mockQuestions[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswerSelect(index)}
                    className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                      selectedAnswers[currentQuestion] === index
                        ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950'
                        : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                          selectedAnswers[currentQuestion] === index
                            ? 'border-indigo-600 bg-indigo-600'
                            : 'border-gray-300 dark:border-gray-600'
                        }`}
                      >
                        {selectedAnswers[currentQuestion] === index && (
                          <div className="w-2 h-2 bg-white rounded-full" />
                        )}
                      </div>
                      <span>{option}</span>
                    </div>
                  </button>
                ))}
              </CardContent>
            </Card>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
                disabled={currentQuestion === 0}
              >
                Previous
              </Button>
              {currentQuestion === mockQuestions.length - 1 ? (
                <Button onClick={handleSubmit} className="flex-1">
                  Submit Test
                </Button>
              ) : (
                <Button
                  onClick={() => setCurrentQuestion(currentQuestion + 1)}
                  className="flex-1"
                >
                  Next Question
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              )}
            </div>
          </TabsContent>

          <TabsContent value="flashcards" className="mt-6">
            <FlashcardViewer flashcards={mockFlashcards} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
