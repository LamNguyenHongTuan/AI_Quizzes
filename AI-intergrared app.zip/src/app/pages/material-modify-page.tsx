import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Brain, ArrowLeft, Plus, X, Save, Trash2 } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { toast } from 'sonner';

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
}

interface Flashcard {
  id: string;
  front: string;
  back: string;
}

// Mock material data
const mockMaterial = {
  id: '1',
  title: 'Introduction to React Hooks',
  tags: ['React', 'JavaScript', 'Frontend'],
  questions: [
    {
      id: 'q1',
      question: 'What is the main purpose of React Hooks?',
      options: [
        'To add animations to components',
        'To use state and other React features without writing a class',
        'To create CSS styles',
        'To handle routing in React applications',
      ],
      correctAnswer: 1,
    },
    {
      id: 'q2',
      question: 'Which hook is used for side effects in React?',
      options: ['useState', 'useEffect', 'useContext', 'useReducer'],
      correctAnswer: 1,
    },
  ],
  flashcards: [
    {
      id: 'f1',
      front: 'What is useState?',
      back: 'useState is a Hook that lets you add React state to function components.',
    },
    {
      id: 'f2',
      front: 'What is useEffect?',
      back: 'useEffect is a Hook that performs side effects in function components.',
    },
  ],
};

export function MaterialModifyPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [title, setTitle] = useState(mockMaterial.title);
  const [tags, setTags] = useState(mockMaterial.tags.join(', '));
  const [questions, setQuestions] = useState<Question[]>(mockMaterial.questions);
  const [flashcards, setFlashcards] = useState<Flashcard[]>(mockMaterial.flashcards);

  // Question handlers
  const addQuestion = () => {
    const newQuestion: Question = {
      id: `q${Date.now()}`,
      question: '',
      options: ['', '', '', ''],
      correctAnswer: 0,
    };
    setQuestions([...questions, newQuestion]);
  };

  const removeQuestion = (id: string) => {
    setQuestions(questions.filter(q => q.id !== id));
  };

  const updateQuestion = (id: string, field: keyof Question, value: any) => {
    setQuestions(questions.map(q =>
      q.id === id ? { ...q, [field]: value } : q
    ));
  };

  const updateQuestionOption = (qId: string, optionIndex: number, value: string) => {
    setQuestions(questions.map(q =>
      q.id === qId
        ? { ...q, options: q.options.map((opt, i) => i === optionIndex ? value : opt) }
        : q
    ));
  };

  // Flashcard handlers
  const addFlashcard = () => {
    const newFlashcard: Flashcard = {
      id: `f${Date.now()}`,
      front: '',
      back: '',
    };
    setFlashcards([...flashcards, newFlashcard]);
  };

  const removeFlashcard = (id: string) => {
    setFlashcards(flashcards.filter(f => f.id !== id));
  };

  const updateFlashcard = (id: string, field: keyof Flashcard, value: string) => {
    setFlashcards(flashcards.map(f =>
      f.id === id ? { ...f, [field]: value } : f
    ));
  };

  const handleSave = () => {
    if (!title.trim()) {
      toast.error('Please provide a title');
      return;
    }
    toast.success('Material updated successfully!');
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate('/dashboard')}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-r from-indigo-600 to-blue-600 p-2 rounded-lg">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-semibold">Modify Material</span>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Material Info */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Material Information</CardTitle>
            <CardDescription>Update your material details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Material Title</Label>
              <Input
                id="title"
                placeholder="e.g., Introduction to React Hooks"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tags">Tags (comma-separated)</Label>
              <Input
                id="tags"
                placeholder="e.g., React, JavaScript, Frontend"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Questions and Flashcards Tabs */}
        <Tabs defaultValue="questions" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="questions">Questions ({questions.length})</TabsTrigger>
            <TabsTrigger value="flashcards">Flashcards ({flashcards.length})</TabsTrigger>
          </TabsList>

          {/* Questions Tab */}
          <TabsContent value="questions" className="space-y-4">
            {questions.map((question, index) => (
              <Card key={question.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Question {index + 1}</CardTitle>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeQuestion(question.id)}
                      className="text-red-600 hover:text-red-700 dark:text-red-400"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Question Text</Label>
                    <Textarea
                      placeholder="Enter your question..."
                      value={question.question}
                      onChange={(e) => updateQuestion(question.id, 'question', e.target.value)}
                    />
                  </div>
                  <div className="space-y-3">
                    <Label>Options</Label>
                    <RadioGroup
                      value={question.correctAnswer.toString()}
                      onValueChange={(value) => updateQuestion(question.id, 'correctAnswer', parseInt(value))}
                    >
                      {question.options.map((option, optIndex) => (
                        <div key={optIndex} className="flex items-center space-x-2">
                          <RadioGroupItem value={optIndex.toString()} id={`${question.id}-opt-${optIndex}`} />
                          <Input
                            placeholder={`Option ${optIndex + 1}`}
                            value={option}
                            onChange={(e) => updateQuestionOption(question.id, optIndex, e.target.value)}
                            className="flex-1"
                          />
                          <Label htmlFor={`${question.id}-opt-${optIndex}`} className="text-xs text-gray-500 dark:text-gray-400">
                            {optIndex === question.correctAnswer && '✓ Correct'}
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Select the radio button to mark the correct answer
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
            <Button onClick={addQuestion} variant="outline" className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              Add Question
            </Button>
          </TabsContent>

          {/* Flashcards Tab */}
          <TabsContent value="flashcards" className="space-y-4">
            {flashcards.map((flashcard, index) => (
              <Card key={flashcard.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Flashcard {index + 1}</CardTitle>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeFlashcard(flashcard.id)}
                      className="text-red-600 hover:text-red-700 dark:text-red-400"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Front (Question)</Label>
                    <Textarea
                      placeholder="Enter the question or term..."
                      value={flashcard.front}
                      onChange={(e) => updateFlashcard(flashcard.id, 'front', e.target.value)}
                      className="min-h-[80px]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Back (Answer)</Label>
                    <Textarea
                      placeholder="Enter the answer or definition..."
                      value={flashcard.back}
                      onChange={(e) => updateFlashcard(flashcard.id, 'back', e.target.value)}
                      className="min-h-[80px]"
                    />
                  </div>
                </CardContent>
              </Card>
            ))}
            <Button onClick={addFlashcard} variant="outline" className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              Add Flashcard
            </Button>
          </TabsContent>
        </Tabs>

        {/* Save Actions */}
        <div className="flex gap-3 mt-6">
          <Button
            onClick={handleSave}
            className="flex-1 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Changes
          </Button>
          <Button
            variant="outline"
            onClick={() => navigate('/dashboard')}
          >
            Cancel
          </Button>
        </div>
      </div>
    </div>
  );
}
