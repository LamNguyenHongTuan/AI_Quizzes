import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Brain, Upload, FileText, ArrowLeft, Loader2 } from 'lucide-react';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { Input } from '../components/ui/input';
import { Progress } from '../components/ui/progress';
import { toast } from 'sonner';

export function UploadMaterialPage() {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [tags, setTags] = useState('');
  const [content, setContent] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleGenerate = async () => {
    if (!title || (!content && !file)) {
      toast.error('Please provide a title and content or upload a file');
      return;
    }

    setIsGenerating(true);
    setProgress(0);

    // Simulate AI generation with progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 10;
      });
    }, 300);

    // Simulate generation time
    setTimeout(() => {
      setIsGenerating(false);
      toast.success('Questions and flashcards generated successfully!');
      navigate('/dashboard');
    }, 3500);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate('/dashboard')}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-lg">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-semibold">AI Learning Platform</span>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Upload Learning Material</CardTitle>
            <CardDescription>
              Upload text or files and let AI generate questions and flashcards automatically
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">Material Title</Label>
              <Input
                id="title"
                placeholder="e.g., Introduction to React Hooks"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                disabled={isGenerating}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="tags">Tags (comma-separated)</Label>
              <Input
                id="tags"
                placeholder="e.g., React, JavaScript, Frontend"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                disabled={isGenerating}
              />
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Add tags to help organize and find your materials
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">Content (Optional if uploading file)</Label>
              <Textarea
                id="content"
                placeholder="Paste your learning material here..."
                className="min-h-[200px]"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                disabled={isGenerating}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="file">Or Upload a File</Label>
              <div className="border-2 border-dashed rounded-lg p-8 text-center hover:border-indigo-400 transition-colors">
                <input
                  id="file"
                  type="file"
                  className="hidden"
                  accept=".txt,.pdf,.docx"
                  onChange={(e) => setFile(e.target.files?.[0] || null)}
                  disabled={isGenerating}
                />
                <label htmlFor="file" className="cursor-pointer">
                  <Upload className="w-12 h-12 mx-auto text-gray-400 dark:text-gray-600 mb-2" />
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {file ? file.name : 'Click to upload or drag and drop'}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                    PDF, DOCX, or TXT (MAX. 10MB)
                  </p>
                </label>
              </div>
            </div>

            {isGenerating && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Generating with AI...</span>
                  <span className="font-medium">{progress}%</span>
                </div>
                <Progress value={progress} />
                <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
                  AI is analyzing your material and creating questions and flashcards
                </p>
              </div>
            )}

            <div className="flex gap-3">
              <Button
                onClick={handleGenerate}
                className="flex-1"
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <FileText className="w-4 h-4 mr-2" />
                    Generate Questions & Flashcards
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate('/dashboard')}
                disabled={isGenerating}
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
