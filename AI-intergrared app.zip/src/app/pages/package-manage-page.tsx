import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Brain, ArrowLeft, Plus, X, Save, Trash2, Package, Tag } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Badge } from '../components/ui/badge';
import { Checkbox } from '../components/ui/checkbox';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { toast } from 'sonner';

// Mock materials available
const availableMaterials = [
  { id: '1', title: 'Introduction to React Hooks', tags: ['React', 'JavaScript'] },
  { id: '2', title: 'JavaScript Fundamentals', tags: ['JavaScript'] },
  { id: '3', title: 'CSS Grid and Flexbox', tags: ['CSS', 'Layout'] },
  { id: '4', title: 'TypeScript Basics', tags: ['TypeScript', 'JavaScript'] },
  { id: '5', title: 'Node.js API Development', tags: ['Node.js', 'Backend'] },
];

// Mock package data
const mockPackage = {
  id: 'pkg1',
  name: 'Web Development Basics',
  tags: ['Web', 'Programming'],
  materialIds: ['1', '2'],
};

export function PackageManagePage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [packageName, setPackageName] = useState(mockPackage.name);
  const [packageTags, setPackageTags] = useState(mockPackage.tags.join(', '));
  const [selectedMaterials, setSelectedMaterials] = useState<Set<string>>(new Set(mockPackage.materialIds));
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  const toggleMaterial = (materialId: string) => {
    const newSelected = new Set(selectedMaterials);
    if (newSelected.has(materialId)) {
      newSelected.delete(materialId);
    } else {
      newSelected.add(materialId);
    }
    setSelectedMaterials(newSelected);
  };

  const handleSave = () => {
    if (!packageName.trim()) {
      toast.error('Package name is required');
      return;
    }
    toast.success('Package saved successfully');
    navigate('/dashboard');
  };

  const handleDelete = () => {
    toast.success('Package deleted');
    navigate('/dashboard');
  };

  const materialsInPackage = availableMaterials.filter(m => selectedMaterials.has(m.id));
  const materialsAvailable = availableMaterials.filter(m => !selectedMaterials.has(m.id));

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate('/dashboard')}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-2 rounded-lg">
              <Package className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-semibold">Manage Package</span>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Package Settings */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Package Settings</CardTitle>
            <CardDescription>Configure your package name and tags</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="packageName">Package Name</Label>
              <Input
                id="packageName"
                value={packageName}
                onChange={(e) => setPackageName(e.target.value)}
                placeholder="e.g., Web Development Basics"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="packageTags">Tags (comma-separated)</Label>
              <Input
                id="packageTags"
                value={packageTags}
                onChange={(e) => setPackageTags(e.target.value)}
                placeholder="e.g., Web, Programming, Frontend"
              />
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Tags help users find your package
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Materials in Package */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Materials in Package ({selectedMaterials.size})</span>
              <Badge className="bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300">
                {selectedMaterials.size} selected
              </Badge>
            </CardTitle>
            <CardDescription>Materials currently in this package</CardDescription>
          </CardHeader>
          <CardContent>
            {materialsInPackage.length > 0 ? (
              <div className="space-y-2">
                {materialsInPackage.map((material) => (
                  <div
                    key={material.id}
                    className="flex items-center justify-between p-3 border rounded-lg bg-purple-50 dark:bg-purple-950/30"
                  >
                    <div className="flex-1">
                      <h4 className="font-medium">{material.title}</h4>
                      <div className="flex gap-2 mt-1">
                        {material.tags.map(tag => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => toggleMaterial(material.id)}
                      className="text-red-600 hover:text-red-700 dark:text-red-400"
                    >
                      <X className="w-4 h-4 mr-1" />
                      Remove
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No materials in this package yet</p>
                <p className="text-sm">Add materials from the section below</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Available Materials */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Add Materials to Package</CardTitle>
            <CardDescription>Select materials to add to this package</CardDescription>
          </CardHeader>
          <CardContent>
            {materialsAvailable.length > 0 ? (
              <div className="space-y-2">
                {materialsAvailable.map((material) => (
                  <div
                    key={material.id}
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800"
                  >
                    <div className="flex-1">
                      <h4 className="font-medium">{material.title}</h4>
                      <div className="flex gap-2 mt-1">
                        {material.tags.map(tag => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => toggleMaterial(material.id)}
                      className="bg-green-50 dark:bg-green-950 text-green-600 hover:text-green-700 dark:text-green-400"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                <p>All your materials are already in this package</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex gap-3">
          <Button
            onClick={handleSave}
            className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Package
          </Button>
          <Button
            variant="outline"
            onClick={() => navigate('/dashboard')}
          >
            Cancel
          </Button>
          <Button
            variant="outline"
            onClick={() => setDeleteDialogOpen(true)}
            className="text-red-600 hover:text-red-700 dark:text-red-400"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Delete Package
          </Button>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Package?</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{packageName}"? This action cannot be undone.
              The materials inside will not be deleted.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete Package
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
