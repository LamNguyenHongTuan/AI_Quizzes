import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Loader2, Sparkles } from 'lucide-react';

interface AIExplanationDialogProps {
  open: boolean;
  onClose: () => void;
  question: string;
  correctAnswer: string;
  selectedAnswer: string;
}

export function AIExplanationDialog({
  open,
  onClose,
  question,
  correctAnswer,
  selectedAnswer,
}: AIExplanationDialogProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [explanation, setExplanation] = useState('');

  useEffect(() => {
    if (open) {
      setIsLoading(true);
      setExplanation('');
      
      // Simulate AI response
      setTimeout(() => {
        const mockExplanation = `The correct answer is "${correctAnswer}" because it accurately addresses the core concept being tested in this question.

Your selected answer "${selectedAnswer}" is incorrect because it doesn't fully capture the intended meaning or may contain misconceptions about the topic.

Here's why the correct answer is better:
1. It directly relates to the fundamental principle being tested
2. It uses precise terminology that aligns with standard definitions
3. It accounts for all aspects mentioned in the question

To improve your understanding, I recommend reviewing the key concepts related to this topic and paying attention to the specific wording used in technical definitions. Would you like me to provide additional resources or examples to help clarify this concept?`;
        
        setExplanation(mockExplanation);
        setIsLoading(false);
      }, 2000);
    }
  }, [open, question, correctAnswer, selectedAnswer]);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-600" />
            AI Explanation
          </DialogTitle>
          <DialogDescription>
            Understanding why your answer was incorrect
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-sm font-medium text-gray-600 mb-1">Question:</p>
            <p>{question}</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-red-50 rounded-lg border border-red-200">
              <p className="text-sm font-medium text-red-800 mb-1">Your Answer:</p>
              <p className="text-sm">{selectedAnswer}</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
              <p className="text-sm font-medium text-green-800 mb-1">Correct Answer:</p>
              <p className="text-sm">{correctAnswer}</p>
            </div>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
              <span className="ml-3 text-gray-600">AI is analyzing your answer...</span>
            </div>
          ) : (
            <div className="p-4 bg-indigo-50 rounded-lg border border-indigo-200">
              <p className="text-sm font-medium text-indigo-900 mb-2">Explanation:</p>
              <div className="text-sm text-gray-700 whitespace-pre-line">{explanation}</div>
            </div>
          )}

          <Button onClick={onClose} className="w-full">
            Got it, thanks!
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
