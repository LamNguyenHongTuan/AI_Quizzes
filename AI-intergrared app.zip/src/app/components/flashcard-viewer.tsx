import { useState } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { ChevronLeft, ChevronRight, RotateCcw } from 'lucide-react';
import { Badge } from './ui/badge';

interface Flashcard {
  id: string;
  front: string;
  back: string;
}

interface FlashcardViewerProps {
  flashcards: Flashcard[];
}

export function FlashcardViewer({ flashcards }: FlashcardViewerProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % flashcards.length);
  };

  const handlePrevious = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + flashcards.length) % flashcards.length);
  };

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  const currentCard = flashcards[currentIndex];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Badge variant="outline">
          Card {currentIndex + 1} of {flashcards.length}
        </Badge>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setCurrentIndex(0);
            setIsFlipped(false);
          }}
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Restart
        </Button>
      </div>

      <div className="perspective-1000">
        <Card
          onClick={handleFlip}
          className="min-h-[300px] cursor-pointer transition-all duration-500 hover:shadow-lg"
          style={{
            transformStyle: 'preserve-3d',
            transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
          }}
        >
          <CardContent className="p-8 flex flex-col items-center justify-center min-h-[300px]">
            <div
              style={{
                backfaceVisibility: 'hidden',
                transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
              }}
            >
              {!isFlipped ? (
                <div className="text-center">
                  <p className="text-sm text-gray-500 mb-4">Question</p>
                  <p className="text-xl">{currentCard.front}</p>
                  <p className="text-sm text-gray-400 mt-8">Click to reveal answer</p>
                </div>
              ) : (
                <div className="text-center">
                  <p className="text-sm text-gray-500 mb-4">Answer</p>
                  <p className="text-xl">{currentCard.back}</p>
                  <p className="text-sm text-gray-400 mt-8">Click to see question</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-3">
        <Button
          variant="outline"
          onClick={handlePrevious}
          disabled={flashcards.length <= 1}
          className="flex-1"
        >
          <ChevronLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>
        <Button onClick={handleNext} disabled={flashcards.length <= 1} className="flex-1">
          Next
          <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </div>

      <div className="flex gap-2 justify-center flex-wrap">
        {flashcards.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setCurrentIndex(index);
              setIsFlipped(false);
            }}
            className={`w-3 h-3 rounded-full transition-all ${
              index === currentIndex ? 'bg-indigo-600 w-8' : 'bg-gray-300 hover:bg-gray-400'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
